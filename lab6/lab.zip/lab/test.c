#include "test.h"
#include <stdio.h>

int min(int a, int b) {
	return a<=b?a:b;
}
void merge(student ls1[], int sz1, student ls2[], int sz2, student ls[]) {
	int i1 = 0, i2 = 0, i = 0;
	while(1) {
		if(i1 == sz1 || i2 == sz2)
			break;
		if(ls1[i1].cgpa <= ls2[i2].cgpa) {
			ls[i] = ls1[i1];
			i1++;
			i++;
		}
		else {
			ls[i] = ls2[i2];
			i2++;
			i++;
		}
	}
	if(i1 != sz1) {
		for(int j = i1; j < sz1; j++) {
			ls[i] = ls1[j];
			i++;
		}
	}
	if(i2 != sz2) {
		for(int j = i2; j < sz2; j++) {
			ls[i] = ls2[j];
			i++;
		}
	}
}

void sort(int l, int r, student ls[]) {
	if(l == r)
		return;
	int mid = (l+r)/2;
	sort(l, mid, ls);
	sort(mid+1, r, ls);
	student ls1[mid-l+1], ls2[r-mid], sorted[r-l+1];
	for(int i = l; i <= mid; i++)
		ls1[i-l] = ls[i];
	for(int i = mid+1; i <= r; i++)
		ls2[i-mid-1] = ls[i];
	merge(ls1, mid-l+1, ls2, r-mid, sorted);
	for(int i = l; i <= r; i++)
		ls[i] = sorted[i-l];
}

void iter_sort(student ls[], int sz) {
	int l = 0, r = sz-1;
	int i_sz = 1;
	while(i_sz < sz) {
		for(int i = 0; i < sz; i = i + 2*i_sz) {
			student ls1[i_sz];
			int sz1 = min(i_sz, sz-i), sz2 = min(i_sz, sz-i-sz1);
			student ls2[sz2];
			//printf("%d  %d   %d   %d\n", i, i+sz1+sz2, i_sz, sz-i-i_sz);
			for(int j = i; j < i + sz1; j++) {
				ls1[j-i] = ls[j];	
			}
			for(int j = i+sz1; j < i+sz1+sz2; j++) {
				ls2[j-sz1-i] = ls[j];
			}
			student sorted[sz1+sz2];
			if(sz2 != 0) {
				merge(ls1, sz1, ls2, sz2, sorted);
				for(int j = i; j < i+sz1+sz2; j++) {
					//printf("%f ", sorted[j-i].cgpa);
					ls[j] = sorted[j-i];
				}
				//printf("\n");
			}
		}
		i_sz = i_sz<<1;
	}
}
























