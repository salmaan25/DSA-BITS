#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "test.h"

int main(void) {
	
	int end = 10240;
	char str[20];
	float cg= 0.0;
	int i = 0;
	FILE *fp = fopen("10240.txt","r");
	student ls[10240];
	//printf("hello\n");
	
	while(fscanf(fp,"%10s,%f",str,&cg) == 2){
		if(i == end){
			break;
			
			/*size *=2;
			arr = (student *)(realloc(arr,(sizeof(student)*size)));*/
		}
		strcpy(ls[i].name, str);
		ls[i].cgpa = cg;
		i++;
	}
	fclose(fp);
	//for(int i = 0; i < end; i++)
		//printf("%f ", ls[i].cgpa);
	//printf("\n");
	iter_sort(ls, end);
	//sort(0, 10239, ls);
	//for(int i = 0; i < end; i++)
		//printf("%f ", ls[i].cgpa);
	//printf("\n");
	return 0;
}
